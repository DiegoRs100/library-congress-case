﻿namespace POC.Service.Cadastro
{
    public interface IUsuarioCadastroChatbotService : ICadastroService
    { }
}
