﻿using POC.Models;

namespace POC.Service.Cadastro
{
    public interface IUsuarioCadastroPortalService : ICadastroService
    { }
}
