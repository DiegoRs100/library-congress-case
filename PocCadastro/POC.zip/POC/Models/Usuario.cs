﻿namespace POC.Models
{
    public class Usuario
    {
        public Guid Id { get; set; }
    }
}
