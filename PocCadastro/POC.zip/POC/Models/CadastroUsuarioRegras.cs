﻿namespace POC.Models
{
    public enum CadastroUsuarioRegras
    {
        Portal = 0,
        Chatbot = 1
    }
}
